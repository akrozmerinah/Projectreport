-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2023 at 05:03 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(60) NOT NULL,
  `password` varchar(150) NOT NULL,
  `username` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `adminName`, `password`, `username`, `email`, `photo`) VALUES
(9, 'Akello rosemary rose', 'good', 'nana', 'akellorosemary03@gmail.com', 'posts-images/169817153038.jpeg'),
(12, 'LLY', '12345', 'lilian', 'edward@gmail.com', 'posts-images/169817174259.jpeg'),
(14, 'Nakato', 'saviour', 'Jesus', 'jesus@gmail.com', 'posts-images/169817158228.jpeg'),
(17, 'Akello rosemary', 'mary', 'rose', 'akellorosemary1999@gmail.com', 'posts-images/169817161856.jpeg'),
(19, 'levis', '098', 'brother', 'mukama@gmail.com', 'posts-images/169817169060.jpeg'),
(21, 'xtin', '123456', 'fify', 'fiffi@gmail.com', 'posts-images/169874123195.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `borrowId` int(11) NOT NULL,
  `memberID` int(11) NOT NULL,
  `borrowDate` date NOT NULL DEFAULT current_timestamp(),
  `returnDate` varchar(20) NOT NULL,
  `equipmentID` int(11) NOT NULL,
  `borrowStatus` enum('borrowed','returned') NOT NULL,
  `fine` varchar(100) NOT NULL,
  `catID` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`borrowId`, `memberID`, `borrowDate`, `returnDate`, `equipmentID`, `borrowStatus`, `fine`, `catID`) VALUES
(15, 2, '2023-07-04', '2023-07-13', 21, 'returned', 'Paid', 9001),
(45, 6, '2023-08-09', '2023-08-10', 23, 'returned', 'Paid', 0),
(46, 8, '2023-08-09', '2023-08-18', 21, 'returned', 'Paid', 0),
(47, 8, '2023-08-10', '2023-08-11', 32, 'returned', 'Paid', 0),
(48, 8, '2023-08-10', '2023-08-25', 33, 'returned', 'Paid', 0),
(49, 8, '2023-08-10', '2023-08-18', 34, 'returned', 'Paid', 0),
(50, 8, '2023-08-10', '2023-08-18', 35, 'returned', 'Paid', 0),
(51, 8, '2023-08-11', '2023-08-13', 36, 'returned', 'Paid', 0),
(52, 8, '2023-08-11', '2023-08-18', 21, 'returned', 'Paid', 0),
(53, 2, '2023-08-14', '2023-08-17', 36, 'returned', 'Paid', 0),
(54, 8, '2023-08-18', '2023-08-19', 21, 'returned', 'Paid', 0),
(55, 8, '2023-08-18', '2023-08-22 19:55:41', 33, 'returned', 'Paid', 0),
(56, 8, '2023-08-18', '2023-08-23 16:35:09', 23, 'returned', 'Paid', 0),
(57, 8, '2023-08-22', '2023-10-26 13:49:55', 38, 'returned', 'Paid', 0),
(58, 8, '2023-08-23', '2023-08-25', 23, 'borrowed', '', 0),
(59, 8, '2023-09-28', '2023-09-28 10:35:36', 35, 'returned', 'Paid', 0),
(60, 8, '2023-10-14', '2023-10-21', 36, 'borrowed', '', 0),
(61, 15, '2023-10-30', '2023-11-04', 40, 'borrowed', '', 0),
(62, 8, '2023-10-31', '2023-11-04', 23, 'borrowed', '', 0),
(63, 8, '2023-10-31', '2023-11-03', 33, 'borrowed', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `catID` int(30) NOT NULL,
  `catName` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`catID`, `catName`) VALUES
(9001, 'Measurement instrument'),
(9002, 'Optics and light'),
(9003, 'Electronics and magnetism'),
(9004, 'Mechanics'),
(9005, 'Thermodynamics'),
(9006, 'Atomic and nuclear'),
(9007, 'safety'),
(9008, 'electronics'),
(9009, 'Computing and data acquisition'),
(9010, 'Dry cells'),
(9011, 'CROs'),
(9012, 'Thermometers'),
(9013, 'Generators');

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

CREATE TABLE `equipments` (
  `equipmentID` int(11) NOT NULL,
  `equipmentName` varchar(150) NOT NULL,
  `serialNo` varchar(150) NOT NULL,
  `photo` text NOT NULL,
  `installationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `quantity` varchar(10) NOT NULL,
  `supplierName` varchar(60) NOT NULL,
  `statuss` varchar(10) NOT NULL,
  `catID` int(30) NOT NULL,
  `supplierContact` varchar(30) NOT NULL,
  `stock` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`equipmentID`, `equipmentName`, `serialNo`, `photo`, `installationDate`, `quantity`, `supplierName`, `statuss`, `catID`, `supplierContact`, `stock`) VALUES
(21, 'Metrix1 oscilloscopey43', '09HH0844:8030', 'posts-images/169599986046.jpeg', '2023-09-29 15:04:20', '1', 'Foska', 'Disposed', 9001, '0752223456', 'Available'),
(23, 'Function generator', 'FG-9As', 'posts-images/169589425897.jpeg', '2023-10-30 22:26:29', '1', 'Dora', 'Normal', 9013, '0703449306', 'Borrowed'),
(32, 'anotherone', 'qwasdgHGD', 'posts-images/169270675625.jpeg', '2023-08-21 21:00:00', '1', 'lydia', 'Scrap', 9003, '0752223450', 'Available'),
(33, 'Baslitic', 'AQWSEDF123Q', 'posts-images/169590408147.jpeg', '2023-10-31 08:35:03', '1', 'chris', 'Normal', 9009, '0752222800', 'Borrowed'),
(34, 'Crocodile clips', 'CAQWVBG4359I', 'posts-images/169590375359.jpeg', '2023-09-28 12:22:34', '1 packet', 'peter', 'Normal', 9004, '0789097760', 'Available'),
(35, 'asdfgh', 'ggggg', 'posts-images/169169269094.jpeg', '2023-09-28 07:35:36', '2', 'dddddd', 'Normal', 9005, '0988765500', 'Available'),
(36, 'Pasonic', 'BNNBBAA66', 'posts-images/169589212315.jpeg', '2023-10-14 10:08:06', '1', 'wailozi', 'Normal', 9010, '0752223488', 'Borrowed'),
(38, 'Glass thermometer', 'ASZZWQ23my', 'posts-images/169590388529.jpeg', '2023-09-28 12:24:45', '1', 'mable', 'Normal', 9012, '07888809776', 'Available'),
(39, 'bulb', 'BL54RQ', 'posts-images/169271657898.jpeg', '2023-08-22 15:02:58', '1', 'Rose', 'Scrap', 9006, '0755776654', 'Available'),
(40, 'Alkaline battery', 'AG10-389A', 'posts-images/169589103544.jpeg', '2023-10-30 08:26:49', '1 packet', 'Hamala Joshua', 'Normal', 9010, '0789933456', 'Borrowed'),
(41, 'Energizer', 'AXZIIY259A0', 'posts-images/169589130157.jpeg', '2023-09-28 08:55:01', '1', 'jane', 'Normal', 9010, '0773477416', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `memberID` int(11) NOT NULL,
  `matric_no` varchar(30) NOT NULL,
  `password` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `email` varchar(60) NOT NULL,
  `dept` varchar(60) NOT NULL,
  `numOfequipments` int(11) NOT NULL,
  `moneyOwed` varchar(20) NOT NULL,
  `photo` text NOT NULL,
  `phoneNumber` varchar(11) NOT NULL,
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`memberID`, `matric_no`, `password`, `username`, `email`, `dept`, `numOfequipments`, `moneyOwed`, `photo`, `phoneNumber`, `name`) VALUES
(2, 'ADSE-9839', '4321', 'akello', 'somygee@gmail.com', 'Software Engineering', 2, '1234', 'posts-images/169817670469.jpeg', '08124578966', 'Cathy'),
(5, '2200224098', 'naka', 'nora', 'nora@gmail.coma', 'ICTiiiii', 0, 'null', 'posts-images/169817510982.jpeg', '0790098987', 'Nora'),
(6, '20034567890', 'tina', 'tina', 'tambiti@gmail.com', 'physics/math', 0, 'null', 'posts-images/169817623522.jpeg', 'tambiti@gma', 'tambiti christine'),
(8, '2200224095215', '12345', 'Hellen', 'rose@gmail.comi', 'physics/econ', 0, 'null', 'posts-images/169817644486.jpeg', '0783322234', 'Roser1'),
(13, 'QZ12FRHYYT', '876', 'lydiana', 'lydia@gmail.com', 'Physics ', 0, 'null', 'posts-images/169817665116.jpeg', '07987654345', 'DR. ACHIENGI LYDIA'),
(15, 'Buup00998', 'fred123', 'fredrick', 'fred@gmail.com', 'ICT', 0, 'null', 'posts-images/169873566391.jpeg', '07064527263', 'Bwire Fred');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `newsId` int(11) NOT NULL,
  `announcement` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`newsId`, `announcement`) VALUES
(23, 'The laboratory is always open from Monday to Friday (Working days only)'),
(26, 'For those who borrowed equipments, should return them back in time to avoid more fines.'),
(27, 'The laboratory is always open from 9am -12pm'),
(28, 'Closed for Lunch time from 1pm - 2pm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`borrowId`),
  ADD KEY `eqp_id` (`equipmentID`),
  ADD KEY `std_id` (`memberID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`catID`);

--
-- Indexes for table `equipments`
--
ALTER TABLE `equipments`
  ADD PRIMARY KEY (`equipmentID`),
  ADD UNIQUE KEY `serialNo` (`serialNo`),
  ADD KEY `categories` (`catID`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`memberID`),
  ADD UNIQUE KEY `matric_no` (`matric_no`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`newsId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `borrow`
--
ALTER TABLE `borrow`
  MODIFY `borrowId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `equipments`
--
ALTER TABLE `equipments`
  MODIFY `equipmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `memberID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `newsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrow`
--
ALTER TABLE `borrow`
  ADD CONSTRAINT `eqp_id` FOREIGN KEY (`equipmentID`) REFERENCES `equipments` (`equipmentID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `std_id` FOREIGN KEY (`memberID`) REFERENCES `members` (`memberID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `equipments`
--
ALTER TABLE `equipments`
  ADD CONSTRAINT `equipments_ibfk_1` FOREIGN KEY (`catID`) REFERENCES `categories` (`catID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
